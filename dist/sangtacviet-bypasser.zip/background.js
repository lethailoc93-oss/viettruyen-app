/**
 * background.js - Chrome Extension Service Worker
 * Connects to ws://localhost:8080/?code=extension_worker
 * Listens for fetch requests, performs them in background or via tab injection, and returns HTML.
 */

let ws = null;
const WS_URL = "ws://localhost:8080/?code=extension_worker";
let isConnected = false;
let reconnectTimer = null;

function connectWS() {
    if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
        return;
    }

    console.log("Attempting to connect to WS Relay:", WS_URL);
    ws = new WebSocket(WS_URL);

    ws.onopen = () => {
        console.log("✅ Connected to WS Relay Server!");
        isConnected = true;
        chrome.action.setBadgeText({ text: "ON" });
        chrome.action.setBadgeBackgroundColor({ color: "#4caf50" });
        if (reconnectTimer) clearInterval(reconnectTimer);
    };

    ws.onmessage = async (event) => {
        try {
            const msg = JSON.parse(event.data);
            // Only process "request" from the relay meant for us
            // We expect format: { event_type: "fetch_request", request_id: "...", url: "...", method: "..." }
            if (msg.event_type !== "fetch_request") return;

            console.log(`📥 Received fetch request [${msg.request_id}] for: ${msg.url}`);

            const html = await executeFetch(msg.url);

            const response = {
                event_type: "fetch_response",
                request_id: msg.request_id,
                url: msg.url,
                html: html,
                success: html.length > 0
            };

            ws.send(JSON.stringify(response));
            console.log(`📤 Sent fetch response [${msg.request_id}], size: ${html.length} bytes`);

        } catch (e) {
            console.error("❌ Error processing message:", e);
        }
    };

    ws.onclose = () => {
        console.log("❌ Disconnected from WS Relay Server.");
        isConnected = false;
        chrome.action.setBadgeText({ text: "OFF" });
        chrome.action.setBadgeBackgroundColor({ color: "#f44336" });

        // Auto-reconnect every 3 seconds
        if (!reconnectTimer) {
            reconnectTimer = setInterval(connectWS, 3000);
        }
    };

    ws.onerror = (e) => {
        console.error("WS Error", e);
        ws.close();
    };
}

// Start connection
connectWS();

/**
 * 1. Tries a background fetch first.
 * 2. If blocked by Cloudflare (403, 503, or contains Turnstile challenge), injects a tab.
 */
async function executeFetch(url) {
    try {
        const res = await fetch(url, {
            headers: {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "vi-VN,vi;q=0.8,en-US;q=0.5,en;q=0.3",
                "Cache-Control": "max-age=0"
            }
        });

        const text = await res.text();

        // Detect Cloudflare blocks
        if (res.status === 403 || res.status === 503 || text.includes("cf-browser-verification") || text.includes("cf-turnstile")) {
            console.log(`⚠️ Cloudflare block detected for ${url} via Background Fetch. Falling back to Tab Injection...`);
            return await fetchViaTabInjection(url);
        }

        return text;
    } catch (err) {
        console.error(`Fetch failed for ${url} background. Trying tab injection...`, err);
        return await fetchViaTabInjection(url);
    }
}

/**
 * Opens a new tab, waits for page to load (checking for CF clearance), 
 * extracts HTML, and closes the tab.
 */
function fetchViaTabInjection(url) {
    return new Promise((resolve) => {
        chrome.tabs.create({ url: url, active: false }, (tab) => {
            const tabId = tab.id;
            let isResolved = false;

            // Listen for tab updates
            const listener = (tid, changeInfo, tabInfo) => {
                if (tid === tabId && changeInfo.status === "complete") {

                    // Execute script to get HTML, checking for CF markers
                    chrome.scripting.executeScript({
                        target: { tabId: tabId },
                        func: () => {
                            const html = document.documentElement.outerHTML;
                            const isCF = html.includes('cf-browser-verification') || document.title.includes('Just a moment');
                            return { html: html, isCF: isCF };
                        }
                    }, (results) => {
                        if (chrome.runtime.lastError) {
                            console.error(chrome.runtime.lastError);
                            if (!isResolved) {
                                isResolved = true;
                                chrome.tabs.onUpdated.removeListener(listener);
                                chrome.tabs.remove(tabId);
                                resolve("");
                            }
                            return;
                        }

                        if (results && results[0] && results[0].result) {
                            const data = results[0].result;
                            if (!data.isCF) {
                                // Success, got real content
                                if (!isResolved) {
                                    isResolved = true;
                                    chrome.tabs.onUpdated.removeListener(listener);
                                    chrome.tabs.remove(tabId);
                                    resolve(data.html);
                                }
                            } else {
                                // Still Cloudflare, maybe wait a bit longer to see if it autorefreshes
                                console.log(`Tab ${tabId} is still on Cloudflare challenge page. Waiting...`);
                            }
                        }
                    });
                }
            };

            chrome.tabs.onUpdated.addListener(listener);

            // Timeout after 30 seconds
            setTimeout(() => {
                if (!isResolved) {
                    isResolved = true;
                    chrome.tabs.onUpdated.removeListener(listener);
                    chrome.tabs.remove(tabId);
                    console.warn(`Tab Injection Timeout for ${url}`);
                    resolve("");
                }
            }, 30000);
        });
    });
}
